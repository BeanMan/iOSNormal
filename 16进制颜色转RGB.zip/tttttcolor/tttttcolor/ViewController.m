//
//  ViewController.m
//  tttttcolor
//
//  Created by bean on 16/4/19.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#define UIColorFromHex(s)  [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0 green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [UIColor colorWithRed:(((0xdcdcdc & 0xFF0000) >> 16))/255.0 green:(((0xdcdcdc &0xFF00) >>8))/255.0 blue:((0xdcdcdc &0xFF))/255.0 alpha:1.0];
    self.view.backgroundColor = UIColorFromHex(0x4c4c4c);
    
    
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    view.backgroundColor = [UIColor colorWithRed:76/255.0 green:76/255.0 blue:76/255.0 alpha:1];
    view.layer.borderColor = [UIColor redColor].CGColor;
    view.layer.borderWidth = 1;
//    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
}

@end
