//
//  ViewController.m
//  international
//
//  Created by bean on 16/4/18.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

//----------------http://www.jianshu.com/p/116d07e064bc-------------------
//http://blog.csdn.net/wangqiuyun/article/details/7875442
/***
 1.首先在项目的project中选中info，点击Localizations添加需要支持的语言环境
 2.新建一个string文件  resource－>string  *******注：文件名必须为Localizable  不然后面就会匹配不到而不起作用，第一个网址中没有说明这一点！！！*******
 3.在Localizable.string中点击localize添加语言
 4.在各个string中定义相应的key=value，必须是双引号
 5.应用即可  NSLocalizedString(@"yes", @"can't find resource file!")
 *******其中yes 就是对应的key  ************************
 ********can't find resource file!是说明没有找到支持的国际化语言文件*********
 
 */




- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:NSLocalizedString(@"hello", @"can't find resource file!") message:nil delegate:nil cancelButtonTitle:NSLocalizedString(@"yes", @"can't find resource file!") otherButtonTitles:nil];
    [alert show];
    
//    1，获取语言支持：
    
    NSUserDefaults*defaults = [ NSUserDefaults standardUserDefaults ];
    
    // 取得 iPhone 支持的所有语言设置
    
    NSArray*languages = [defaults objectForKey :@"AppleLanguages"];
    
    NSLog (@"%@", languages);
    
//    2，获取当前使用语言
    
//    [objc]view plaincopy
    
    NSArray*languages2 = [NSLocale preferredLanguages];
    
    NSString*currentLanguage = [languages2 objectAtIndex:0];
    
    NSLog (@"%@", currentLanguage);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
