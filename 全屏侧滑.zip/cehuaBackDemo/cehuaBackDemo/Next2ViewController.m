//
//  Next2ViewController.m
//  cehuaBackDemo
//
//  Created by bean on 16/3/4.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "Next2ViewController.h"

@interface Next2ViewController ()

@end

@implementation Next2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
    
    // 创建全屏滑动手势，调用系统自带滑动手势的target的action方法
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleNavigationTransition:)];
    
    
    // 给导航控制器的view添加全屏滑动手势
    [view addGestureRecognizer:pan];
    
   
    
    
}

- (void)handleNavigationTransition: (UIPanGestureRecognizer*)pan{
    
    NSLog(@"22222");
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
