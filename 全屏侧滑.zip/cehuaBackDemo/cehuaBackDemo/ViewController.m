//
//  ViewController.m
//  cehuaBackDemo
//
//  Created by bean on 16/3/4.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

    
}

- (void)click
{
    NextViewController * view = [[NextViewController alloc]init];
    
    
    [self.navigationController pushViewController:view animated:YES];
    
}

@end
